<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( 'MYALBUM_CNST_LOADED' ) ) {


// Appended by Xoops Language Checker -GIJOE- in 2004-05-05 15:14:39
define('_ALBM_CAPTION_CATEGORY','Category');

define( 'MYALBUM_CNST_LOADED' , 1 ) ;

// System Constants (Don't Edit)
define( "GPERM_INSERTABLE" , 1 ) ;
define( "GPERM_SUPERINSERT" , 2 ) ;
define( "GPERM_EDITABLE" , 4 ) ;
define( "GPERM_SUPEREDIT" , 8 ) ;
define( "GPERM_DELETABLE" , 16 ) ;
define( "GPERM_SUPERDELETE" , 32 ) ;
define( "GPERM_TOUCHOTHERS" , 64 ) ;
define( "GPERM_SUPERTOUCHOTHERS" , 128 ) ;
define( "GPERM_RATEVIEW" , 256 ) ;
define( "GPERM_RATEVOTE" , 512 ) ;

// Global Group Permission
define( "_ALBM_GPERM_G_INSERTABLE" , "Envio (requer aprova��o)" ) ;
define( "_ALBM_GPERM_G_SUPERINSERT" , "Super Envio" ) ;
define( "_ALBM_GPERM_G_EDITABLE" , "Editar (requer aprova��o)" ) ;
define( "_ALBM_GPERM_G_SUPEREDIT" , "Super Edi��o" ) ;
define( "_ALBM_GPERM_G_DELETABLE" , "Excluir (requer aprova��o)" ) ;
define( "_ALBM_GPERM_G_SUPERDELETE" , "Super Dele��o" ) ;
define( "_ALBM_GPERM_G_TOUCHOTHERS" , "Tocar em fotos enviadas por outros" ) ;
define( "_ALBM_GPERM_G_SUPERTOUCHOTHERS" , "Super toque outros" ) ;
define( "_ALBM_GPERM_G_RATEVIEW" , "Ver Ranking" ) ;
define( "_ALBM_GPERM_G_RATEVOTE" , "Voto" ) ;

// Caption
define( "_ALBM_CAPTION_TOTAL" , "Total:" ) ;
define( "_ALBM_CAPTION_GUESTNAME" , "Convidado" ) ;
define( "_ALBM_CAPTION_REFRESH" , "Atualizar" ) ;
define( "_ALBM_CAPTION_IMAGEXYT" , "Tamanho(tipo)" ) ;

}

?>
