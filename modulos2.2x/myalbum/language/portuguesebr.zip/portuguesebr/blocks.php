<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( 'MYALBUM_BL_LOADED' ) ) {



// Appended by Xoops Language Checker -GIJOE- in 2004-07-31 16:23:29
define('_ALBM_TEXT_COLS','Columns of Photos');

// Appended by Xoops Language Checker -GIJOE- in 2004-05-05 15:14:39
define('_ALBM_TEXT_CATLIMITATION','Limit by category');
define('_ALBM_TEXT_CATLIMITRECURSIVE','with Subcategories');
define('_ALBM_TEXT_RANDOMCYCLE','Switching cycle of random images (sec)');

define( 'MYALBUM_BL_LOADED' , 1 ) ;

// Blocks
define("_ALBM_BTITLE_TOPNEW","Recent Photos");
define("_ALBM_BTITLE_TOPHIT","Top Photos");
define("_ALBM_BTITLE_RANDOM","Pic Up Photo");
define("_ALBM_TEXT_DISP","Display");
define("_ALBM_TEXT_STRLENGTH","Max length of photo's title");
define("_ALBM_TEXT_BLOCK_WIDTH","Displays max");
define("_ALBM_TEXT_BLOCK_WIDTH_NOTES","(if you set here 0, the thumbnail image displays its original size.)");

}

?>
